<?php

namespace App\Http\Controllers\Api\Barber;

use JWTAuth;
use App\User;
use App\Booking;
use App\Service;
use Carbon\Carbon;
use App\WorkingDay;
use App\Transaction;
use DateTime;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class OccupancyController extends Controller
{
    public function index(Request $req)
    {
        $req->validate([
            'time' => 'required',
        ]);

        $barber = JWTAuth::user();
        $day = Carbon::createFromFormat('m/d/Y',Carbon::now()->format('m/d/Y'),'Asia/Karachi')->format('l');
        $date = Carbon::createFromFormat('m/d/Y',Carbon::now()->format('m/d/Y'),'Asia/Karachi')->format('m/d/Y');
        $workingday = WorkingDay::where('user_id',$barber->id)->whereHas('day',function($q) use($day){
            $q->where('title',$day);
        })->first();
        $occupied = Booking::whereHas('service.barber',function($q) use($date,$barber){
            $q->where('user_id',$barber->id)->where('date',$date);
        })->get();
        
        $begin = new DateTime($workingday->open);
        $end = new DateTime($workingday->close);
        $slots = [];
        while($begin < $end) {
            $output = $begin->format('h:i a');
            // $output = $begin->format('H:i A') . " - ";
            $begin->modify('+30 minutes');          /** Note, it modifies time by 15 minutes */
            // $output .= $begin->format('H:i A');
            $slots[] = $output;
        }
        $bookeds = array();
        $counts = 0;
        foreach($occupied as $occ){
            $booked_begin = new DateTime($occ->from_time);
            $booked_end = new DateTime($occ->to_time);
            $i = 0;
            while($booked_begin < $booked_end) {
                $booked = $booked_begin->format('h:i a');
                // $output = $begin->format('H:i A') . " - ";
                $booked_begin->modify('+30 minutes');          /** Note, it modifies time by 15 minutes */
                // $output .= $begin->format('H:i A');
                // $bookeds[$i+=1] = $booked;
                array_push($bookeds, $booked);
                // array_push($bookeds, $booked);
                $counts = array_count_values($bookeds);
            }   
        }
        // foreach($bookeds as $bo){
        //     $key = array_search($bo, $slots);
        //     if (false !== $key) {
        //         if($counts[$bo] >= $barber->seats){
        //             unset($slots[$key]);
        //         }
        //     }
        // }
        $barber->booking = count($occupied);
        $barber->occupied = count(array_keys($bookeds, $req->time));
        $barber->available = $barber->seats - count(array_keys($bookeds, $req->time));
        $barber->slots = $slots;
        return response()->json([
            'success' => true,
            'barber' => $barber,
        ], 200);
    }

}
