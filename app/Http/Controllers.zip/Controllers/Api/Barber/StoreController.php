<?php

namespace App\Http\Controllers\Api\Barber;

use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Product;
use App\Service;
use JWTAuth;

class StoreController extends Controller
{
    public function store(Request $req)
    {
        $stores = User::with('favourite')->where('name', 'like', '%' . $req->title . '%')->whereHas('roles', function ($q) {
            $q->where('name', 'seller');
        })->get()->makeHidden(['operational_hours','email','email_verified_at']);

        return response()->json([
            'success' => true,
            'stores' => $stores,
        ], 200);
    }
    public function showStore($id)
    {
        $store = User::with('favourite')->whereHas('roles', function ($q) {
            $q->where('name', 'seller');
        })->where('id',$id)->first()->makeHidden(['email','email_verified_at']);
        $store->products = $product = Product::with('favourite')->with('media')->where('user_id', $id)->get();
        if ($product) {
            return response()->json([
                'success' => true,
                'store' => $store,
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'not found',
            ], 404);
        }
    }
    public function product(Request $req)
    {
        $products = Product::with('favourite')->where('title', 'like', '%' . $req->title . '%')->with('seller:id,name','media')->where('status','1')->get();
        return response()->json([
            'success' => true,
            'products' => $products,
        ], 200);
    }

}
