<?php $__env->startSection('content'); ?>

    <div class="main-panel">
      <div class="content-wrapper pb-0">
          <h3>Comming Soon</h3>
      </div>
    </div>
    <!-- main-panel ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cosmeciety\resources\views/404.blade.php ENDPATH**/ ?>