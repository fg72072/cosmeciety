<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
      <div class="page-header">
        <h3 class="page-title">List Products</h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">List Product</li>
          </ol>
        </nav>
      </div>
      <div class="row">
        <div class="col-lg-12 col-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <div class="add-btn-section">
                <a class="btn btn-primary" href="<?php echo e(url('product/create')); ?>">Add Product</a>
              </div>
              </p>
              <div class="table-responsive">
                <table class="table table-hover datatable ">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Product</th>
                      <th>Category</th>
                      <th>Short Intro</th>
                      <th>Seller</th>
                      <th>Price</th>
                      <th>Stock</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($product->id); ?></td>
                      <td>
                        <div class="d-flex align-items-center">
                          <img src="<?php echo e(asset('assets/images/product/'.$product->img)); ?>" alt="image" />
                          <div class="table-user-name ml-3">
                            <p class="mb-0 font-weight-medium"> <?php echo e($product->title); ?> </p>
                          </div>
                        </div>
                      </td>
                      <td><?php echo e($product->category->title); ?></td>
                      <td><?php echo e($product->description); ?></td>
                      <td><?php echo e($product->seller->name); ?></td>
                      <td>$<?php echo e($product->price); ?></td>
                      <td><?php echo e($product->stock); ?></td>
                      <td>
                        <?php if($product->status == 1): ?>
                        <label class="badge badge-success">Active</label>
                        <?php else: ?>
                        <label class="badge badge-danger">Unactive</label>
                        <?php endif; ?>
                      </td>
                      <td>
                        <div class="btn-flex">
                            <a href="<?php echo e(url('product/edit/'.$product->id)); ?>" class="btn text-white btn-success btn-icon-text">
                                <i class="mdi mdi-pencil-box-outline btn-icon-prepend"></i> Edit </a>
                            <form action="<?php echo e(url('product/delete/'.$product->id)); ?>" method="post" class="delete-form">
                            <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger btn-icon-text">
                                    <i class="mdi mdi-delete-forever btn-icon-prepend"></i> Delete </button>
                            </form>
                        
                        </div>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cosmeciety\resources\views/product/list.blade.php ENDPATH**/ ?>