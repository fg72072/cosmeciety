<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
      <div class="page-header">
        <h3 class="page-title">List Order</h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('index')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">List Order</li>
          </ol>
        </nav>
      </div>
      <div class="row">
        <div class="col-lg-12 col-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              
              </p>
              <div class="table-responsive">
                <table class="table table-hover datatable">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>User</th>
                      <th>SubTotal</th>
                      <th>Tax</th>
                      <th>GrandTotal</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td>
                      <div class="d-flex align-items-center">
                        <img src="<?php echo e($order->user->img ? asset('assets/images/user/'.$order->user->img) : asset('assets/images/faces/face1.jpg')); ?>" alt="image" />
                        <div class="table-user-name ml-3">
                          <p class="mb-0 font-weight-medium"> <?php echo e($order->user->name); ?> </p>
                        </div>
                      </div>
                    </td>
                    <td>
                    $<?php echo e($order->subtotal); ?>

                    </td>
                    <td>
                      $<?php echo e($order->tax); ?>

                    </td>
                    <td>
                      $<?php echo e($order->grand_total); ?>

                    </td>
                    <td>
                      <?php if($order->deliveryStatus->title == "Pending" || $order->deliveryStatus->title == "Cancel"): ?>
                      <label class="badge badge-danger"><?php echo e($order->deliveryStatus->title); ?></label>
                      <?php elseif($order->deliveryStatus->title == "Confirm" || $order->deliveryStatus->title == "Delivered"): ?>
                      <label class="badge badge-danger"><?php echo e($order->deliveryStatus->title); ?></label>
                      <?php endif; ?>
                    </td>
                    <td>
                      <div class="btn-flex">
                          <a href="<?php echo e(url('order/edit/'.$order->id)); ?>" class="btn text-white btn-success btn-icon-text">
                              <i class="mdi mdi-pencil-box-outline btn-icon-prepend"></i> Edit </a>
                          
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cosmeciety\resources\views/orders/list.blade.php ENDPATH**/ ?>