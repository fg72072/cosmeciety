
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Cosmeciety</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/mdi/css/materialdesignicons.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/css/vendor.bundle.base.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/font-awesome/css/font-awesome.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/select2/select2.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/select2-bootstrap-theme/select2-bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/datatable.css')); ?>" />
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" />
</head>

<body>
      <div class="custom-form-layout">
        <div class="row w-100">
            <div class="custom-form-width m-auto grid-margin stretch-card">
                   <div class="card">
                     <div class="card-body">
                       
                       <div class="text-center">
                           <img src="<?php echo e(asset('assets/images/logo.png')); ?>"/>
                       </div>
                       <form class="forms-sample" method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <div id="profile-container">
                                <img class="radius-50" id="profileImage" src="<?php echo e(asset('assets/images/faces/face1.jpg')); ?>" alt="Upload Image"
                                    data-holder-rendered="true" max-height="10px;" max-width="100px;"
                                    style="height:100px;width:100px;">
                            </div>
                            <br>
                            <input id="imageUpload" style="display: none" type="file" name="avatar" placeholder="Photo" capture=""
                                value="">
                            <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="mt-1">
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            
                            <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" id="name" placeholder="Name" />
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                         </div>
                         <div class="form-group">
                           
                           <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" id="exampleInputEmail1" placeholder="Email" />
                           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="invalid-feedback">
                               <strong><?php echo e($message); ?></strong>
                           </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                        </div>
                        <div class="form-group">
                            
                            <input type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" id="phone" placeholder="Phone" />
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                         </div>
                         <div class="form-group">
                           
                           <input type="password" class="form-control" id="exampleInputPassword1" name="password"  autocomplete="current-password" placeholder="Password" />
                           <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <span class="invalid-feedback">
                                   <strong><?php echo e($message); ?></strong>
                               </span>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </div>
                         <div class="form-group">
                            
                            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required autocomplete="password_confirmation" placeholder="Confirm Password" />
                          </div>
                         
                         <button type="submit" class="btn btn-primary mr-2"> Register </button>
                                    <a class="btn btn-link" href="<?php echo e(url('login')); ?>">
                                        Already have an account?
                                    </a>
                       </form>
                     </div>
                   </div>
                 </div>
          </div>
      </div>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cosmeciety\resources\views/auth/register.blade.php ENDPATH**/ ?>