<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <div class="text-center sidebar-brand-wrapper d-flex align-items-center">
      <a class="sidebar-brand brand-logo" href="<?php echo e(url('index')); ?>"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo" /></a>
      <a class="sidebar-brand brand-logo-mini pl-4 pt-3" href="<?php echo e(url('index')); ?>"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo" /></a>
    </div>
    <ul class="nav">
      
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">
          <i class="mdi mdi-home menu-icon"></i>
          <span class="menu-title">Dashboard</span>
        </a>
      </li>
      <?php if(auth()->check() && auth()->user()->hasRole('seller')): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('product')); ?>">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Products</span>
        </a>
    
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('inventory/create')); ?>">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Inventory Section</span>
        </a>
      </li>
      <?php endif; ?>
      
      <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('user')); ?>">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Users</span>
        </a>
      </li>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('category')); ?>">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Category</span>
        </a>
      </li>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('seller')): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('order')); ?>">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Orders</span>
        </a>
    
      </li>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('topic')); ?>">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Social Forum</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('wall')); ?>">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Wall</span>
        </a>
      </li>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('contest')); ?>">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Contest</span>
        </a>
      </li>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('transaction')); ?>">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Transaction</span>
        </a>
      </li>
      <?php endif; ?>
    </ul>
  </nav><?php /**PATH C:\xampp\htdocs\cosmeciety\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>