<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <div class="text-center sidebar-brand-wrapper d-flex align-items-center">
      <a class="sidebar-brand brand-logo" href="<?php echo e(url('index')); ?>"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo" /></a>
      <a class="sidebar-brand brand-logo-mini pl-4 pt-3" href="<?php echo e(url('index')); ?>"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo" /></a>
    </div>
    <ul class="nav">
      
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">
          <i class="mdi mdi-home menu-icon"></i>
          <span class="menu-title">Dashboard</span>
        </a>
      </li>
      <?php if(auth()->check() && auth()->user()->hasRole('seller')): ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#product" aria-expanded="false" aria-controls="product">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Products</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="product">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('product')); ?>">List</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('product/create')); ?>">Add</a>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('inventory/create')); ?>">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Add Inventory</span>
        </a>
      </li>
      <?php endif; ?>
      
      <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#user" aria-expanded="false" aria-controls="user">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Users</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="user">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('user')); ?>">List</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('user/create')); ?>">Add</a>
            </li>
          </ul>
        </div>
      </li>
      <?php endif; ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#category" aria-expanded="false" aria-controls="category">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Category</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="category">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('category')); ?>">List</a>
            </li>
            <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('category/create')); ?>">Add</a>
            </li>
            <?php endif; ?>
          </ul>
        </div>
      </li>
      <?php if(auth()->check() && auth()->user()->hasRole('seller')): ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#order" aria-expanded="false" aria-controls="order">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Orders</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="order">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('order')); ?>">List</a>
            </li>
          </ul>
        </div>
      </li>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#topic" aria-expanded="false" aria-controls="topic">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Social Forum</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="topic">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('topic')); ?>">List</a>
            </li>
            
          </ul>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#wall" aria-expanded="false" aria-controls="wall">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Wall</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="wall">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('wall')); ?>">List</a>
            </li>
            
          </ul>
        </div>
      </li>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#contest" aria-expanded="false" aria-controls="contest">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Contest</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="contest">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('contest')); ?>">List</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('contest/create')); ?>">Add</a>
            </li>
          </ul>
        </div>
      </li>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#transaction" aria-expanded="false" aria-controls="transaction">
          <i class="mdi mdi-content-cut menu-icon"></i>
          <span class="menu-title">Transaction</span>
          <i class="menu-arrow"></i>
        </a>
        <div class="collapse" id="transaction">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('transaction')); ?>">List</a>
            </li>
            
          </ul>
        </div>
      </li>
      <?php endif; ?>
    </ul>
  </nav><?php /**PATH C:\xampp\htdocs\cosmeciety\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>