<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
      <div class="page-header">
        <h3 class="page-title">List Category</h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">List Category</li>
          </ol>
        </nav>
      </div>
      <div class="row">
        <div class="col-lg-12 col-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              
              </p>
              <div class="table-responsive">
                <table class="table table-hover datatable ">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Title</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($category->id); ?></td>
                      <td><?php echo e($category->title); ?></td>
                      <td>
                        <?php if($category->status == 1): ?>
                        <label class="badge badge-success">Active</label>
                        <?php else: ?>
                        <label class="badge badge-danger">Unctive</label>
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if(auth()->check() && auth()->user()->hasRole('super-admin')): ?>
                        <div class="btn-flex">
                          <?php if($category->id != 1): ?>
                          <a href="<?php echo e(url('category/edit/'.$category->id)); ?>" class="btn text-white btn-success btn-icon-text">
                              <i class="mdi mdi-pencil-box-outline btn-icon-prepend"></i> Edit </a>
                              
                            <form action="<?php echo e(url('category/delete/'.$category->id)); ?>" method="post" class="delete-form">
                              <?php echo csrf_field(); ?>
                              <button type="submit" class="btn btn-danger btn-icon-text">
                                <i class="mdi mdi-delete-forever btn-icon-prepend"></i> Delete </button>
                              </form>
                            <?php endif; ?>
                      
                      </div>
                        <?php endif; ?>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cosmeciety\resources\views/category/list.blade.php ENDPATH**/ ?>