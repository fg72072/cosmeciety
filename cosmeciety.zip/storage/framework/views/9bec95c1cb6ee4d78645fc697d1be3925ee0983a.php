<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
      <div class="page-header">
        <h3 class="page-title">Edit User</h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page"> Edit User </li>
          </ol>
        </nav>
      </div>
      <div class="row ">
        <div class="col-12 grid-margin ">
          <div class="card">
            <div class="card-body">
              <form class="forms-sample" action="<?php echo e(url('user/update/'.$user->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <div id="profile-container">
                      <img class="" id="profileImage" src="<?php echo e(asset('assets/images/user/'.$user->img)); ?>" alt="Upload Image" data-holder-rendered="true" max-height="10px;" max-width="100px;" style="height:100px;width:100px;">
                  </div>
                  <br>
                  <input id="imageUpload" type="file" name="image" placeholder="Photo" capture="" value="">
                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="mt-1">
                      <span class="text-danger"><?php echo e($message); ?></span>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                <div class="form-group">
                  <label for="name">Name</label>
                  <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" id="name" placeholder="Name" />
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="mt-1">
                    <span class="text-danger"><?php echo e($message); ?></span>
                  </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" value="<?php echo e($user->email); ?>" name="email" id="email" placeholder="Email" />
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="mt-1">
                      <span class="text-danger"><?php echo e($message); ?></span>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                  <label for="phone">Phone</label>
                  <input type="phone" class="form-control" name="phone" value="<?php echo e($user->phone); ?>" id="phone" placeholder="Phone" />
                  <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="mt-1">
                    <span class="text-danger"><?php echo e($message); ?></span>
                  </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               </div>
               <div class="form-group">
                <label for="location">Location</label>
                <input type="location" class="form-control" value="<?php echo e($user->location); ?>" name="location" id="location" placeholder="Location" />
                <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="mt-1">
                  <span class="text-danger"><?php echo e($message); ?></span>
                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <?php if(Auth::user()->id != $user->id): ?>
              <div class="form-group">
                <label for="status">Status</label>
                <select class="form-control" name="status" id="status" style="width: 100%;">
                    <option value="1" <?php if($user->status == 1): ?> selected <?php endif; ?>>Active</option>
                    <option value="0" <?php if($user->status == 0): ?> selected <?php endif; ?>>Unactive</option>
                  </select>
              </div>
              <?php endif; ?>
                <button type="submit" class="btn btn-primary mr-2"> Update </button>
                
                </div>
                <div class="col-md-6">
                  
                
                  
                </div>
                </div>
              </form>
              <?php if(Auth::user()->id == $user->id): ?>
              <form action="<?php echo e(url('user/update/'.$user->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
              <div class="row">
                <div class="col-md-6 mt-5">
                  <h3 class="mb-3">Change Password</h3>
                  <input type="hidden" name="change_pass" value="yes"/>
                  <div class="form-group">
                    <label for="current_password">Current Password</label>
                    <input type="password" required class="form-control" name="current_password" id="current_password" placeholder="Current Password" />
                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="mt-1">
                      <span class="text-danger"><?php echo e($message); ?></span>
                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  
                    </div>
                  <div class="form-group">
                  <label for="password">Password</label>
                  <input type="password" class="form-control" name="password" id="password" placeholder="Password" />
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="mt-1">
                    <span class="text-danger"><?php echo e($message); ?></span>
                  </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <?php if(session('error')): ?>
                  <div class="mt-1">
                    <span class="text-danger"><?php echo e(session('error')); ?></span>
                  </div>
                  <?php endif; ?>
                  </div>
                  <div class="form-group">
                  <label for="password_confirmation">Confirm Password</label>
                  <input type="password" class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Confirm Password" />
                  <?php if(session('success')): ?>
                  <div class="mt-1">
                    <span class="text-success"><?php echo e(session('success')); ?></span>
                  </div>
                  <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary mr-2"> Update </button>
              </div>
            </div>
          </form>
            <?php endif; ?>
            </div>
            
          </div>
          
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cosmeciety\resources\views/user/edit.blade.php ENDPATH**/ ?>