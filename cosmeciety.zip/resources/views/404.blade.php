@extends('layouts.app')

@section('content')

    <div class="main-panel">
      <div class="content-wrapper pb-0">
          <h3>Comming Soon</h3>
      </div>
    </div>
    <!-- main-panel ends -->
@endsection
